package com.coppercraft;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.World;
import net.minecraft.world.chunk.IChunkProvider;
import net.minecraft.world.gen.IChunkGenerator;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.common.registry.IForgeRegistry;
import net.minecraftforge.oredict.OreDictionary;
import net.minecraft.block.BlockOre;

import java.util.Random;

@Mod(modid = CopperCraft.MODID, name = CopperCraft.NAME, version = CopperCraft.VERSION)
@Mod.EventBusSubscriber
public class CopperCraft {
    public static final String MODID = "coppercraft";
    public static final String NAME = "CopperCraft";
    public static final String VERSION = "1.0";

    public static final CreativeTabs TAB = new CreativeTabs("coppercraft") {
        @Override public ItemStack getTabIconItem() {
            return new ItemStack(COPPER_INGOT);
        }
    };

    public static Block COPPER_ORE;
    public static Block COPPER_BLOCK;
    public static Item COPPER_INGOT;

    @SubscribeEvent
    public static void registerBlocks(RegistryEvent.Register<Block> event) {
        COPPER_ORE = new BlockOre()
                .setHardness(3.0F).setResistance(5.0F)
                .setHarvestLevel("pickaxe", 1)
                .setRegistryName(MODID, "copper_ore")
                .setUnlocalizedName(MODID + ".copper_ore")
                .setCreativeTab(TAB);
        COPPER_BLOCK = new Block(Material.IRON)
                .setHardness(5.0F).setResistance(10.0F)
                .setHarvestLevel("pickaxe", 1)
                .setRegistryName(MODID, "copper_block")
                .setUnlocalizedName(MODID + ".copper_block")
                .setCreativeTab(TAB);
        event.getRegistry().registerAll(COPPER_ORE, COPPER_BLOCK);
    }

    @SubscribeEvent
    public static void registerItems(RegistryEvent.Register<Item> event) {
        COPPER_INGOT = new Item()
                .setRegistryName(MODID, "copper_ingot")
                .setUnlocalizedName(MODID + ".copper_ingot")
                .setCreativeTab(TAB);

        ItemBlock oreItem = new ItemBlock(COPPER_ORE).setRegistryName(COPPER_ORE.getRegistryName());
        ItemBlock blockItem = new ItemBlock(COPPER_BLOCK).setRegistryName(COPPER_BLOCK.getRegistryName());
        event.getRegistry().registerAll(COPPER_INGOT, oreItem, blockItem);
    }

    @SubscribeEvent
    public static void registerRecipes(RegistryEvent.Register<net.minecraft.item.crafting.IRecipe> event) {
        GameRegistry.addSmelting(COPPER_ORE, new ItemStack(COPPER_INGOT), 0.7F);
        // 9 copper ingots -> 1 copper block
        net.minecraft.item.crafting.IRecipe recipe = new net.minecraft.item.crafting.ShapedRecipes(
                "coppercraft", 3, 3,
                new net.minecraft.item.ItemStack[] {
                    new ItemStack(COPPER_INGOT), new ItemStack(COPPER_INGOT), new ItemStack(COPPER_INGOT),
                    new ItemStack(COPPER_INGOT), new ItemStack(COPPER_INGOT), new ItemStack(COPPER_INGOT),
                    new ItemStack(COPPER_INGOT), new ItemStack(COPPER_INGOT), new ItemStack(COPPER_INGOT)
                }, new ItemStack(COPPER_BLOCK));
        event.getRegistry().register(recipe.setRegistryName(MODID, "copper_block"));
    }

    @EventHandler
    public void init(FMLInitializationEvent event) {
        GameRegistry.registerWorldGenerator(new CopperWorldGenerator(), 0);
        OreDictionary.registerOre("oreCopper", COPPER_ORE);
        OreDictionary.registerOre("ingotCopper", COPPER_INGOT);
        OreDictionary.registerOre("blockCopper", COPPER_BLOCK);
    }

    public static class CopperWorldGenerator implements net.minecraftforge.fml.common.IWorldGenerator {
        @Override
        public void generate(Random random, int chunkX, int chunkZ, World world,
                             IChunkGenerator chunkGenerator, IChunkProvider chunkProvider) {
            if (world.provider.getDimension() != 0) return;
            for (int i = 0; i < 20; i++) {
                int x = chunkX * 16 + random.nextInt(16);
                int y = random.nextInt(64);
                int z = chunkZ * 16 + random.nextInt(16);
                net.minecraft.world.gen.feature.WorldGenMinable gen =
                        new net.minecraft.world.gen.feature.WorldGenMinable(
                                COPPER_ORE.getDefaultState(), 8);
                gen.generate(world, random, new net.minecraft.util.math.BlockPos(x, y, z));
            }
        }
    }
}
